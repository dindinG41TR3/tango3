#!/bin/bash
sudo cp Tango3 /usr/share/icons/
echo '===================================='
echo ' OK DONE INSTALL SUKSES '
echo '===================================='
